let groceryList = [];
let counter = 0;
let parent;
let obj;
let template;

function save() {
  let itemInput = document.getElementById("item-input");
  let notification = document.getElementById("notification");
  let quantityInput = document.getElementById("quantity-input");
  let shoppingList = document.getElementById("shopping-list");
  let shoppingNum = document.getElementById("shopping-num");
  let newRow = template.cloneNode(true);
  newRow.childNodes[1].textContent = itemInput.value;
  newRow.childNodes[3].textContent = quantityInput.value;

  let item = {
    id: counter++,
    name: itemInput.value,
    quantity: quantityInput.value
  }

  shoppingNum.textContent = counter;
  groceryList.push(item);
  newRow.classList.toggle('hide');
  shoppingList.innerHTML = shoppingList.innerHTML + '<li id=' + item.id + ' onclick="addToCompleted(this)">' + newRow.innerHTML + '</li>';
}

function deleteItem($ele) {
  parent = $ele.parentElement;
  let notification = document.getElementById("notification");
  counter--;

  if (confirm('Sigurno želiš obrisati ovaj proizvod?')) {
    groceryList = groceryList.filter(item => Number(parent.attributes['id'].value) !== item.id);
    console.log(groceryList);
    parent.classList.add("hide");
    notification.innerHTML = '<span class="txt">Obrisano! </span';
    let shoppingNum = document.getElementById("shopping-num");
    shoppingNum.textContent = counter;
    notification.classList.toggle('notification-delete');
    notification.classList.toggle('hide');
    setTimeout(function () {
      notification.classList.toggle('hide');
      notification.classList.toggle('notification-delete');
      notification.innerHTML = '';
    }, 500);
  }
}
function editItem($ele) {
  parent = $ele.parentElement;
  let notification = document.getElementById("notification");
  let modal = document.getElementById("myModal");
  let span = document.getElementsByClassName("close")[0];
  let input = document.getElementsByClassName("accept")[0];

  modal.style.display = "block";

  span.onclick = function () {
    modal.style.display = "none";
  }

}
function myFunction() {
  let element = document.body;
  let input = document.getElementsByClassName('input-element');
  let txt = document.getElementsByClassName('txt');
  let button = document.getElementsByClassName('delete');
  let modal = document.getElementById("modal-content");
  let toggle = document.getElementById("dark");
  let div = document.getElementById("div-content");
  let submitBtn = document.getElementById("submit-btn-2");

  input[0].classList.toggle("dark-mode-element");
  input[1].classList.toggle("dark-mode-element");
  input[2].classList.toggle("dark-mode-element");
  input[3].classList.toggle("dark-mode-element");
  toggle.classList.toggle("dark");
  element.classList.toggle("dark-mode");
  modal.classList.toggle("dark-mode-div");
  div.classList.toggle("dark-mode-div");
  submitBtn.classList.toggle('dark-mode-txt');
  txt[0].classList.toggle("dark-mode-txt-black");
  txt[1].classList.toggle("dark-mode-txt");
  txt[2].classList.toggle("dark-mode-txt");
  txt[3].classList.toggle("dark-mode-txt-black");
  txt[4].classList.toggle("dark-mode-txt");
  txt[5].classList.toggle("dark-mode-txt");
  txt[6].classList.toggle("dark-mode-txt-black");
  for (let i = 0; i < button.length; i++) {
    button[i].classList.toggle('dark-mode-txt-black');
  }
}
function editSave(ele) {
  let itemInput = document.getElementById("item-input-edit");
  let notification = document.getElementById("notification");
  let quantityInput = document.getElementById("quantity-input-edit");
  let modal = document.getElementById("myModal");

  parent.childNodes[1].textContent = itemInput.value;
  parent.childNodes[3].textContent = quantityInput.value;

  notification.innerHTML = '<span class="txt"> Ažurirano! </span';
  notification.classList.toggle('notification-save');
  notification.classList.toggle('hide');
  modal.style.display = "none";
  setTimeout(function () {
    notification.classList.toggle('hide');
    notification.classList.toggle('notification-save');
    notification.innerHTML = '';
  }, 500);
}

function storeJSON() {
  let notification = document.getElementById("notification");

  notification.innerHTML = '<span class="txt"> Spremljeno! </span';
  notification.classList.toggle('notification-save');
    notification.classList.toggle('hide');
    setTimeout(function () {
      notification.classList.toggle('hide');
      notification.classList.toggle('notification-save');
      notification.innerHTML = '';
    }, 500);
  const shoppingListJSON = JSON.stringify(groceryList);
  localStorage.setItem("shoppingListJSON", shoppingListJSON);
  console.log(obj)
}

function retrieveJSON() {
  let text = localStorage.getItem("shoppingListJSON");
  obj = JSON.parse(text);

  console.log(obj);
}

window.addEventListener('DOMContentLoaded', (event) => {
  console.log('DOM fully loaded and parsed');
  template = document.getElementById("template");
  let shoppingList = document.getElementById("shopping-list");
  retrieveJSON();
  if (obj) {
    obj.forEach(element => {
      counter++;

      let newRow = template.cloneNode(true);

      newRow.childNodes[1].textContent = element.name;
      newRow.childNodes[3].textContent = element.quantity;

      groceryList.push(element);
      newRow.classList.toggle('hide');
      shoppingList.innerHTML = '<li id=' + element.id + ' onclick="addToCompleted(this)">' + newRow.innerHTML + '</li>' + shoppingList.innerHTML;

    });
  }
  let shoppingNum = document.getElementById("shopping-num");
  shoppingNum.textContent = counter;
});


